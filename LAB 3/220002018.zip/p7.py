# Q7 Open a text file and write, “Hello Python” in that file.

file = open("text.txt", "w")
file.write("Hello Python")
file.close()