This is the second DBMS lab assignment submitted by 

Name : Arnav Jain
Roll Number : 220002018 